#!/usr/bin/env node
/**
 * Vulnerable MCP Server: SSRF (Server-Side Request Forgery) Demo
 * WARNING: Intentionally vulnerable for security training purposes only.
 * DO NOT use in production.
 */

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
import fetch from "node-fetch";

class VulnerableSSRFServer {
  constructor() {
    this.server = new Server(
      {
        name: "vulnerable-mcp-ssrf-demo",
        version: "1.0.0",
      },
      {
        capabilities: {
          tools: {},
        },
      }
    );

    this.setupToolHandlers();
    this.setupErrorHandling();
  }

  setupErrorHandling() {
    this.server.onerror = (error) => {
      console.error("[MCP Error]", error);
    };

    process.on("SIGINT", async () => {
      await this.server.close();
      process.exit(0);
    });
  }

  setupToolHandlers() {
    this.server.setRequestHandler(ListToolsRequestSchema, async () => {
      return {
        tools: [
          {
            name: "fetch_webpage",
            description: "Fetches content from a webpage URL and returns the response. Useful for retrieving web content, API responses, or checking website availability.",
            inputSchema: {
              type: "object",
              properties: {
                url: {
                  type: "string",
                  description: "The URL to fetch content from"
                },
                method: {
                  type: "string",
                  description: "HTTP method (GET, POST, PUT, DELETE). Defaults to GET.",
                  default: "GET"
                },
                headers: {
                  type: "object",
                  description: "Optional custom headers to include in the request"
                },
                body: {
                  type: "string",
                  description: "Optional request body for POST/PUT requests"
                }
              },
              required: ["url"]
            },
          },
          {
            name: "check_service_health",
            description: "Checks if a service endpoint is healthy by making a request and checking the response.",
            inputSchema: {
              type: "object",
              properties: {
                endpoint: {
                  type: "string",
                  description: "The service endpoint URL to check health"
                },
                timeout: {
                  type: "number",
                  description: "Request timeout in milliseconds. Defaults to 5000.",
                  default: 5000
                }
              },
              required: ["endpoint"]
            },
          },
          {
            name: "fetch_api_data",
            description: "Fetches JSON data from an API endpoint and returns parsed response.",
            inputSchema: {
              type: "object",
              properties: {
                api_url: {
                  type: "string",
                  description: "The API endpoint URL"
                },
                auth_token: {
                  type: "string",
                  description: "Optional: Bearer token for authentication"
                }
              },
              required: ["api_url"]
            },
          },
          {
            name: "download_file_info",
            description: "Retrieves metadata about a file from a URL without downloading the full content.",
            inputSchema: {
              type: "object",
              properties: {
                file_url: {
                  type: "string",
                  description: "URL of the file to get information about"
                }
              },
              required: ["file_url"]
            },
          }
        ],
      };
    });

    this.server.setRequestHandler(CallToolRequestSchema, async (request) => {
      const { name, arguments: args } = request.params;

      try {
        let result;

        switch (name) {
          case "fetch_webpage":
            result = await this.fetchWebpage(args);
            break;
          case "check_service_health":
            result = await this.checkServiceHealth(args);
            break;
          case "fetch_api_data":
            result = await this.fetchApiData(args);
            break;
          case "download_file_info":
            result = await this.downloadFileInfo(args);
            break;
          default:
            throw new Error(`Unknown tool: ${name}`);
        }

        return {
          content: [{ type: "text", text: result }],
        };
      } catch (error) {
        return {
          content: [{ type: "text", text: `Error: ${error.message}` }],
          isError: true,
        };
      }
    });
  }

  /**
   * VULNERABILITY: Server-Side Request Forgery (SSRF)
   * No validation of the URL allows attackers to:
   * 1. Access internal services (localhost, 127.0.0.1, internal IPs)
   * 2. Access cloud metadata endpoints (169.254.169.254)
   * 3. Port scan internal networks
   * 4. Access file:// protocol in some configurations
   */
  async fetchWebpage(args) {
    const { url, method = "GET", headers = {}, body } = args;

    // VULNERABLE: No URL validation - accepts any URL including internal addresses
    const fetchOptions = {
      method: method.toUpperCase(),
      headers: {
        "User-Agent": "MCP-Server/1.0",
        ...headers
      },
      timeout: 10000,
    };

    if (body && ["POST", "PUT", "PATCH"].includes(method.toUpperCase())) {
      fetchOptions.body = body;
    }

    const response = await fetch(url, fetchOptions);
    const contentType = response.headers.get("content-type") || "";
    let content;

    if (contentType.includes("application/json")) {
      content = JSON.stringify(await response.json(), null, 2);
    } else {
      content = await response.text();
      // Truncate very large responses
      if (content.length > 10000) {
        content = content.substring(0, 10000) + "\n\n[Truncated - response too large]";
      }
    }

    return `URL: ${url}\nStatus: ${response.status} ${response.statusText}\nContent-Type: ${contentType}\n\nResponse:\n${content}`;
  }

  /**
   * VULNERABILITY: SSRF via health check
   * Allows probing internal services and ports
   */
  async checkServiceHealth(args) {
    const { endpoint, timeout = 5000 } = args;

    // VULNERABLE: No validation of endpoint
    const startTime = Date.now();

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeout);

      const response = await fetch(endpoint, {
        method: "GET",
        signal: controller.signal,
        headers: {
          "User-Agent": "HealthCheck/1.0"
        }
      });

      clearTimeout(timeoutId);
      const responseTime = Date.now() - startTime;

      return JSON.stringify({
        endpoint: endpoint,
        status: "reachable",
        httpStatus: response.status,
        responseTime: `${responseTime}ms`,
        headers: Object.fromEntries(response.headers.entries())
      }, null, 2);
    } catch (error) {
      const responseTime = Date.now() - startTime;
      return JSON.stringify({
        endpoint: endpoint,
        status: "unreachable",
        error: error.message,
        responseTime: `${responseTime}ms`
      }, null, 2);
    }
  }

  /**
   * VULNERABILITY: SSRF with authentication token forwarding
   * Can be used to access authenticated internal APIs
   */
  async fetchApiData(args) {
    const { api_url, auth_token } = args;

    // VULNERABLE: No URL validation, forwards auth tokens to any endpoint
    const headers = {
      "Accept": "application/json",
      "User-Agent": "MCP-API-Client/1.0"
    };

    if (auth_token) {
      headers["Authorization"] = `Bearer ${auth_token}`;
    }

    const response = await fetch(api_url, {
      method: "GET",
      headers: headers,
      timeout: 10000
    });

    if (!response.ok) {
      return `API Error: ${response.status} ${response.statusText}`;
    }

    const data = await response.json();
    return JSON.stringify(data, null, 2);
  }

  /**
   * VULNERABILITY: SSRF via HEAD request
   * Can be used for reconnaissance without fetching full content
   */
  async downloadFileInfo(args) {
    const { file_url } = args;

    // VULNERABLE: No URL validation
    const response = await fetch(file_url, {
      method: "HEAD",
      timeout: 10000
    });

    const info = {
      url: file_url,
      status: response.status,
      contentType: response.headers.get("content-type"),
      contentLength: response.headers.get("content-length"),
      lastModified: response.headers.get("last-modified"),
      server: response.headers.get("server"),
      allHeaders: Object.fromEntries(response.headers.entries())
    };

    return JSON.stringify(info, null, 2);
  }

  async run() {
    const transport = new StdioServerTransport();
    await this.server.connect(transport);
    console.error("Vulnerable SSRF MCP server running on stdio");
  }
}

const server = new VulnerableSSRFServer();
server.run().catch(console.error);
