#!/usr/bin/env python3
"""
Vulnerable MCP Server: SQL Injection Demo
WARNING: Intentionally vulnerable for security training purposes only.
DO NOT use in production.
"""

import asyncio
import json
import sys
import sqlite3
from pathlib import Path

class VulnerableDatabaseMCP:
    def __init__(self):
        self.version = "1.0.0"
        self.db_path = Path(__file__).parent / "users.db"
        self._init_database()

    def _init_database(self):
        """Initialize SQLite database with sample data"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Create users table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                username TEXT NOT NULL,
                email TEXT NOT NULL,
                role TEXT DEFAULT 'user',
                api_key TEXT
            )
        ''')

        # Create secrets table (sensitive data)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS secrets (
                id INTEGER PRIMARY KEY,
                secret_name TEXT NOT NULL,
                secret_value TEXT NOT NULL
            )
        ''')

        # Insert sample data if tables are empty
        cursor.execute("SELECT COUNT(*) FROM users")
        if cursor.fetchone()[0] == 0:
            sample_users = [
                ('alice', 'alice@example.com', 'user', 'ak_user_abc123'),
                ('bob', 'bob@example.com', 'user', 'ak_user_def456'),
                ('admin', 'admin@internal.corp', 'admin', 'ak_admin_SUPER_SECRET_789'),
                ('service_account', 'svc@internal.corp', 'service', 'ak_svc_PRODUCTION_KEY_xyz')
            ]
            cursor.executemany(
                "INSERT INTO users (username, email, role, api_key) VALUES (?, ?, ?, ?)",
                sample_users
            )

            sample_secrets = [
                ('database_password', 'Pr0d_DB_P@ssw0rd_2024!'),
                ('jwt_signing_key', 'super_secret_jwt_key_never_share'),
                ('aws_access_key', 'AKIAIOSFODNN7EXAMPLE'),
                ('stripe_api_key', 'sk_live_abcdefghijklmnop123456')
            ]
            cursor.executemany(
                "INSERT INTO secrets (secret_name, secret_value) VALUES (?, ?)",
                sample_secrets
            )

        conn.commit()
        conn.close()

    async def handle_message(self, message: dict) -> dict:
        method = message.get("method")
        msg_id = message.get("id")

        if msg_id is None:
            return None

        if method == "initialize":
            return self._initialize_response(msg_id)
        elif method == "tools/list":
            return self._tools_list_response(msg_id)
        elif method == "tools/call":
            return await self._handle_tool_call(message)

        return self._error_response(msg_id, -32601, "Method not found")

    def _initialize_response(self, msg_id):
        return {
            "jsonrpc": "2.0",
            "id": msg_id,
            "result": {
                "protocolVersion": "2024-11-05",
                "serverInfo": {
                    "name": "vulnerable-mcp-sqli-demo",
                    "version": self.version
                },
                "capabilities": {"tools": {}}
            }
        }

    def _tools_list_response(self, msg_id):
        return {
            "jsonrpc": "2.0",
            "id": msg_id,
            "result": {
                "tools": [
                    {
                        "name": "search_users",
                        "description": "Search for users by username. Returns matching user profiles.",
                        "inputSchema": {
                            "type": "object",
                            "properties": {
                                "username": {
                                    "type": "string",
                                    "description": "Username to search for (supports partial matches)"
                                }
                            },
                            "required": ["username"]
                        }
                    },
                    {
                        "name": "get_user_by_id",
                        "description": "Get user details by their ID number.",
                        "inputSchema": {
                            "type": "object",
                            "properties": {
                                "user_id": {
                                    "type": "string",
                                    "description": "The user ID to look up"
                                }
                            },
                            "required": ["user_id"]
                        }
                    },
                    {
                        "name": "list_users_by_role",
                        "description": "List all users with a specific role.",
                        "inputSchema": {
                            "type": "object",
                            "properties": {
                                "role": {
                                    "type": "string",
                                    "description": "Role to filter by (user, admin, service)"
                                }
                            },
                            "required": ["role"]
                        }
                    }
                ]
            }
        }

    async def _handle_tool_call(self, message: dict) -> dict:
        params = message.get("params", {})
        tool_name = params.get("name")
        arguments = params.get("arguments", {})
        msg_id = message.get("id")

        try:
            if tool_name == "search_users":
                result = self._search_users(arguments.get("username", ""))
            elif tool_name == "get_user_by_id":
                result = self._get_user_by_id(arguments.get("user_id", ""))
            elif tool_name == "list_users_by_role":
                result = self._list_users_by_role(arguments.get("role", ""))
            else:
                return self._error_response(msg_id, -32602, f"Unknown tool: {tool_name}")

            return {
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {
                    "content": [{"type": "text", "text": result}]
                }
            }
        except Exception as e:
            return {
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {
                    "content": [{"type": "text", "text": f"Error: {str(e)}"}]
                }
            }

    def _search_users(self, username: str) -> str:
        """
        VULNERABILITY: SQL Injection via string concatenation
        User input is directly concatenated into SQL query without sanitization.
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # VULNERABLE: Direct string concatenation
        query = f"SELECT id, username, email, role FROM users WHERE username LIKE '%{username}%'"

        try:
            cursor.execute(query)
            rows = cursor.fetchall()
            conn.close()

            if not rows:
                return f"No users found matching '{username}'"

            result = "Found users:\n"
            for row in rows:
                result += f"  ID: {row[0]}, Username: {row[1]}, Email: {row[2]}, Role: {row[3]}\n"
            return result
        except sqlite3.Error as e:
            conn.close()
            return f"Database error: {str(e)}"

    def _get_user_by_id(self, user_id: str) -> str:
        """
        VULNERABILITY: SQL Injection via string formatting
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # VULNERABLE: String formatting without parameterization
        query = "SELECT id, username, email, role FROM users WHERE id = %s" % user_id

        try:
            cursor.execute(query)
            row = cursor.fetchone()
            conn.close()

            if not row:
                return f"No user found with ID {user_id}"

            return f"User found:\n  ID: {row[0]}\n  Username: {row[1]}\n  Email: {row[2]}\n  Role: {row[3]}"
        except sqlite3.Error as e:
            conn.close()
            return f"Database error: {str(e)}"

    def _list_users_by_role(self, role: str) -> str:
        """
        VULNERABILITY: SQL Injection via f-string
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # VULNERABLE: f-string interpolation in SQL
        query = f"SELECT id, username, email FROM users WHERE role = '{role}'"

        try:
            cursor.execute(query)
            rows = cursor.fetchall()
            conn.close()

            if not rows:
                return f"No users found with role '{role}'"

            result = f"Users with role '{role}':\n"
            for row in rows:
                result += f"  ID: {row[0]}, Username: {row[1]}, Email: {row[2]}\n"
            return result
        except sqlite3.Error as e:
            conn.close()
            return f"Database error: {str(e)}"

    def _error_response(self, msg_id, code: int, message: str) -> dict:
        return {
            "jsonrpc": "2.0",
            "id": msg_id,
            "error": {"code": code, "message": message}
        }


async def main():
    server = VulnerableDatabaseMCP()
    print("Vulnerable SQL Injection MCP Server started", file=sys.stderr)

    while True:
        try:
            line = await asyncio.get_event_loop().run_in_executor(None, sys.stdin.readline)
            if not line:
                break

            message = json.loads(line)
            response = await server.handle_message(message)

            if response is not None:
                print(json.dumps(response), flush=True)
        except json.JSONDecodeError:
            continue
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            break


if __name__ == "__main__":
    asyncio.run(main())
